function print(){
    console.log('Hi')
}
print()